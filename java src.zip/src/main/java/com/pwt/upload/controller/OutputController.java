package com.pwt.upload.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pwt.upload.model.OutputData;
import com.pwt.upload.repository.OutputRepository;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/")
public class OutputController {
	
	final org.slf4j.Logger logger = LoggerFactory.getLogger(OutputController.class);
	
	@Autowired
	private OutputRepository outputRepository;
	
	@GetMapping("OutputData/{id}")
//	@RequestMapping(method = RequestMethod.GET, path = "/{id}")
	public  ResponseEntity<OutputData> getOutput(@PathVariable(value="id") String id){
		Optional<OutputData> data = outputRepository.findById(id);
		return new ResponseEntity<>(data.get(), HttpStatus.OK);
	}
//	
	@PostMapping(path ="OutputData/{id}")
//			produces = MediaType.APPLICATION_JSON_VALUE,
//			consumes = MediaType.APPLICATION_JSON_VALUE)
//	@RequestMapping(method = RequestMethod.POST, path = "/{id}")

	public  ResponseEntity<OutputData> getOutput1(@PathVariable(value="id") String id){
		Optional<OutputData> data = outputRepository.findById(id);
		return new ResponseEntity<>(data.get(), HttpStatus.OK);
	}
//	
	
//	
	@PostMapping(path ="OutputData",
		produces = MediaType.APPLICATION_JSON_VALUE,
		consumes = MediaType.APPLICATION_JSON_VALUE)
public  void ResponseEntity(@RequestBody OutputData newOutput){
		OutputData outputData = outputRepository.save(newOutput);
		
	}
//	
	

	
	@GetMapping("OutputData")
	public  List<OutputData> getCompleteOutput(){
		return this.outputRepository.findAll();
	}
	
	@PutMapping("OutputData/{id}")
	public ResponseEntity<OutputData> updateData(@RequestBody final OutputData updatedData){
		OutputData data = outputRepository.saveAndFlush(updatedData);
//		OutputData dat = outputRepository.
		return new ResponseEntity<>(data, HttpStatus.OK);
	}
	
	@GetMapping("OutputDataByAuditId")
	public List<OutputData> getOutputByUserIdAndAuditId(@RequestParam String auditId) {
	    
	    return outputRepository.findByAuditId(auditId);
	  }
	
	@GetMapping("UserDataByAuditId")
	public List<Object> getOutputByAudit_id(@RequestParam String auditId) {
	    
	    return outputRepository.fetchUserData(auditId);
	  }
	
	@GetMapping("getOutputByIds")
	
	public List<OutputData> getAccountById(@RequestParam List<String> outputId) {
	    
		long startTime = System.currentTimeMillis();

	    List<OutputData> op= outputRepository.findAllById(outputId);
	    long duration = System.currentTimeMillis() - startTime;		
		logger.error("getOutputById = " + duration ) ;

	    
	    if(op.isEmpty()) {
	    	
	    	logger.error("output data is empty");
//	    	OutputData o = new OutputData();
//	    	o.setAccountId("12");
//	    	o.setAuditId("");
//	    	o.setId("12");
//	    	o.setRemarks("");
//	    	o.setResult("");
//	    	o.setStatus("");
//	    	o.setTestId("");
//	    	o.setUserId("");
//	    	logger.error("output data is empty o = " + o);
	    	logger.error("output data is empty " + outputId);
	    	op.add(new OutputData("","","","","","","", "","","","",""));
//	    	return (List<OutputData>) new OutputData("","","","","","","", "");
//	    	logger.error("output data is empty op size = " + op.size());
	    }
	    
	    return op;
	  }
	
	
	
	@PutMapping("ListOutputData")

	
	public List<OutputData> updateMultipleData(@RequestBody List<OutputData> updatedData){
		
		logger.error("UpdatedData = > " + updatedData);
		
//		List<OutputData> op = outputRepository.saveAll(updatedData);
		
		long startTime = System.currentTimeMillis();
		List<OutputData> op = outputRepository.saveAllAndFlush(updatedData);
		long duration = System.currentTimeMillis() - startTime;		
		logger.error("ListOutputData = " + duration ) ;

		logger.error("op => " + op.size());
		
		return op;
		
//		OutputData dat = outputRepository.
//		return new ResponseEntity<>(data, HttpStatus.OK);
	}
	
	
}
