
package com.pwt.upload.model;

public class PartyTestData {
	
	private String id;
	
	private String objective;
	private String process;	
	private String subProcess;
	private String testRef;
	private String testTitle;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getObjective() {
		return objective;
	}
	public void setObjective(String objective) {
		this.objective = objective;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public String getSubProcess() {
		return subProcess;
	}
	public void setSubProcess(String subProcess) {
		this.subProcess = subProcess;
	}
	public String getTestRef() {
		return testRef;
	}
	public void setTestRef(String testRef) {
		this.testRef = testRef;
	}
	public String getTestTitle() {
		return testTitle;
	}
	public void setTestTitle(String testTitle) {
		this.testTitle = testTitle;
	}
	
	public PartyTestData(String id, String objective, String process, String subProcess, String testRef,
			String testTitle) {
		super();
		this.id = id;
		this.objective = objective;
		this.process = process;
		this.subProcess = subProcess;
		this.testRef = testRef;
		this.testTitle = testTitle;
	}
	public PartyTestData() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PartyTestData [id=" + id + ", objective=" + objective + ", process=" + process + ", subProcess="
				+ subProcess + ", testRef=" + testRef + ", testTitle=" + testTitle + "]";
	}
	
	
	
	
	

}
