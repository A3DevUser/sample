package com.pwt.upload.model;

public class UserCount {
	
	private String userName;
	int total;
	int mandatoryCount;
	int nonMandatoryCount;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getMandatoryCount() {
		return mandatoryCount;
	}
	public void setMandatoryCount(int mandatoryCount) {
		this.mandatoryCount = mandatoryCount;
	}
	public int getNonMandatoryCount() {
		return nonMandatoryCount;
	}
	public void setNonMandatoryCount(int nonMandatoryCount) {
		this.nonMandatoryCount = nonMandatoryCount;
	}
	public UserCount(String userName, int total, int mandatoryCount, int nonMandatoryCount) {
		super();
		this.userName = userName;
		this.total = total;
		this.mandatoryCount = mandatoryCount;
		this.nonMandatoryCount = nonMandatoryCount;
	}
	public UserCount() {
		super();
	}
	
	

}
