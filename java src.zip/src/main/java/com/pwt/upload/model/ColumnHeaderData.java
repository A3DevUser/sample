package com.pwt.upload.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AAA_COLUMN_HEADER")
public class ColumnHeaderData {

	@Id
	@Column(name="SR_NO")
	private int srNo;
	
	@Column(name="FORM_NAME")
	private String formName;
	
	@Column(name="FIELD_NAME")
	private String fieldName;
	
	@Column(name="ACCESSOR")
	private String accessor;
	
	@Column(name="COLUMN_FILTER")
	private String columnFilter;
	
	@Column(name="STICKY")
	private String sticky;

	public int getSrNo() {
		return srNo;
	}

	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getAccessor() {
		return accessor;
	}

	public void setAccessor(String accessor) {
		this.accessor = accessor;
	}

	public String getColumnFilter() {
		return columnFilter;
	}

	public void setColumnFilter(String columnFilter) {
		this.columnFilter = columnFilter;
	}

	public String getSticky() {
		return sticky;
	}

	public void setSticky(String sticky) {
		this.sticky = sticky;
	}

	public ColumnHeaderData(int srNo, String formName, String fieldName, String accessor, String columnFilter,
			String sticky) {
		super();
		this.srNo = srNo;
		this.formName = formName;
		this.fieldName = fieldName;
		this.accessor = accessor;
		this.columnFilter = columnFilter;
		this.sticky = sticky;
	}

	public ColumnHeaderData() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
