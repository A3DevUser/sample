package com.pwt.upload.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AAA_OUTPUT")
public class OutputData {
	
	@Id
	@Column(name = "id")
	private String id;
	@Column(name = "test_id")
	private String testId;
	@Column(name = "account_id")
	private String accountId;
	@Column(name = "result")
	private String result;
	@Column(name = "remarks")
	private String remarks;
	@Column(name = "user_id")
	private String userId;
	@Column(name = "audit_id")
	private String auditId;
	@Column(name = "status")
	private String status;
	@Column(name = "test_title")
	private String testTitle;
	@Column(name = "scheme_code")
	private String schemeCode;
	@Column(name = "action_status")
	private String actionStatus;
	@Column(name = "audit_type")
	private String auditType;
	
	public String getActionStatus() {
		return actionStatus;
	}

	public void setActionStatus(String actionStatus) {
		this.actionStatus = actionStatus;
	}

	public String getAuditType() {
		return auditType;
	}

	public void setAuditType(String auditType) {
		this.auditType = auditType;
	}

	public String getTimeSt() {
		return timeSt;
	}

	public void setTimeSt(String timeSt) {
		this.timeSt = timeSt;
	}

	public String getIsFinCreated() {
		return isFinCreated;
	}

	public void setIsFinCreated(String isFinCreated) {
		this.isFinCreated = isFinCreated;
	}
	@Column(name = "timestamp")
	private String timeSt;
	@Column(name = "is_fin_created")
	private String isFinCreated;
	
	public String getTestTitle() {
		return testTitle;
	}

	public void setTestTitle(String testTitle) {
		this.testTitle = testTitle;
	}

	public String getSchemeCode() {
		return schemeCode;
	}

	public void setSchemeCode(String schemeCode) {
		this.schemeCode = schemeCode;
	}

	public OutputData(String id, String testId, String accountId, String result, String remarks, String userId,
			String auditId, String status, String testTitle, String schemeCode, String timeSt, String isFinCreated) {
		super();
		this.id = id;
		this.testId = testId;
		this.accountId = accountId;
		this.result = result;
		this.remarks = remarks;
		this.userId = userId;
		this.auditId = auditId;
		this.status = status;
		this.testTitle = testTitle;
		this.schemeCode = schemeCode;
		this.timeSt = timeSt;
		this.isFinCreated = isFinCreated;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OutputData() {
		
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	
	
	
	
	

}
