package com.pwt.upload.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pwt.upload.model.OutputData;

@Repository

public interface OutputRepository extends JpaRepository<OutputData, String> {

	List<OutputData> findByAuditId(String auditId);
	
	@Query(value = "select user_Id,count(distinct account_id) from AAA_OUTPUT where audit_Id = ?1 group by user_Id", nativeQuery = true)
	List<Object> fetchUserData(@Param("auditId") String auditId);
	

}
