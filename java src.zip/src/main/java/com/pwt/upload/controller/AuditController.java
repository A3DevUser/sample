package com.pwt.upload.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pwt.upload.model.AuditData;
import com.pwt.upload.repository.AuditRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/")
public class AuditController {
	
	@Autowired
	private AuditRepository auditRepository;
	
	@GetMapping("AuditData/{id}")
	public Optional<AuditData> getAccountById(@PathVariable String id) {
	    
	    return auditRepository.findById(id);
	  }

}
