package com.pwt.upload.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pwt.upload.model.AuditData;

@Repository
public interface AuditRepository extends JpaRepository<AuditData, String> {
	
	
}
