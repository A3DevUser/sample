package com.pwt.upload.model;

public class UserData {
	
	String userName;
	int count;
	
	public UserData(String userName, int count) {
		super();
		this.userName = userName;
		this.count = count;
	}
	
	
}
