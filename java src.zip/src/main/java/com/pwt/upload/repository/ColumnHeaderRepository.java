package com.pwt.upload.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pwt.upload.model.ColumnHeaderData;

public interface ColumnHeaderRepository extends JpaRepository<ColumnHeaderData, Integer> {

}
